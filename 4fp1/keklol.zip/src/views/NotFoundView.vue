<template>
  <div class="about">
    <h1>This is an NotFound page</h1>
  </div>
</template>

<script>
export default {
    name: "NotFound",
}
</script>